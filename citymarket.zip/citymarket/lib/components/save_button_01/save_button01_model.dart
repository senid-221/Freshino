import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'save_button01_widget.dart' show SaveButton01Widget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SaveButton01Model extends FlutterFlowModel<SaveButton01Widget> {
  ///  Local state fields for this component.

  bool save = false;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
