import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'canceled_order_card_widget.dart' show CanceledOrderCardWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CanceledOrderCardModel extends FlutterFlowModel<CanceledOrderCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
