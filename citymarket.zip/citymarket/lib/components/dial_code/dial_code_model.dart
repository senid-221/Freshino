import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'dial_code_widget.dart' show DialCodeWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DialCodeModel extends FlutterFlowModel<DialCodeWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
