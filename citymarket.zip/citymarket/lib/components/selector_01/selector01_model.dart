import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'selector01_widget.dart' show Selector01Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Selector01Model extends FlutterFlowModel<Selector01Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
