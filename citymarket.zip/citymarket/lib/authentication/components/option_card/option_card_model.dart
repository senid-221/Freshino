import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'option_card_widget.dart' show OptionCardWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class OptionCardModel extends FlutterFlowModel<OptionCardWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
